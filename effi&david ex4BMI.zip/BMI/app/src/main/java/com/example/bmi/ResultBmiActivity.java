package com.example.bmi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultBmiActivity extends AppCompatActivity implements View.OnClickListener{
    private TextView valueFN;
    private TextView valueBmi;
    private TextView valueCurrentWeghit;
    private TextView valueIdealWeghit;
    private Button buttonBack;
    private Button buttonE;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activiy_result_bmi);
        String array[]=getIntent().getStringArrayExtra("arrayInfo");
        valueFN=(TextView)findViewById(R.id.valueFN);
        valueFN.setText(array[0]);
        valueBmi=(TextView)findViewById(R.id.valueBmi);
        valueBmi.setText(array[1]);
        valueCurrentWeghit=(TextView)findViewById(R.id.valueCurrentWeghit);
        valueCurrentWeghit.setText(array[2]);
        valueIdealWeghit=(TextView)findViewById(R.id.valueIdealWeghit);
        valueIdealWeghit.setText(array[3]);
        buttonBack=(Button) findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(this);
        buttonE=(Button) findViewById(R.id.buttonE);
        buttonE.setOnClickListener(this);
    }

    public void onClick(View view){
        Intent i;
        switch (view.getId()){
            case R.id.buttonBack:
                i = new Intent(this, MainActivity.class);
                startActivity(i);
                finish();
                break;

            case R.id.buttonE:
                finish();
                break;
        }

    }
}
