package com.example.bmi;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.preference.TwoStatePreference;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
   private RadioButton buttonFemale;
    private RadioButton buttonMale;
    private RadioButton largeB;
    private RadioButton mediumB;
    private RadioButton bSmall;
    private Button exitB;
    private Button sendB;
    private EditText editTextTextPersonNameF;
    private EditText editTextTextPersonNameL;
    private EditText editTextNumberA;
    private double slimness=0;
    private SeekBar height;
    private SeekBar weight;
    private TextView vlaueHeight;
    private TextView vlaueWeight;
    private int valueH=0;
    private int valueW=0;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextTextPersonNameF = (EditText) findViewById(R.id.editTextTextPersonNameF);
        editTextTextPersonNameL = (EditText) findViewById(R.id.editTextTextPersonNameL);
        editTextNumberA = (EditText) findViewById(R.id.editTextNumberA);
        buttonFemale = (RadioButton) findViewById(R.id.buttonFemale);
        buttonMale = (RadioButton) findViewById(R.id.buttonMale);
        buttonMale.setOnClickListener(this);
        buttonFemale.setOnClickListener(this);
        bSmall = (RadioButton) findViewById(R.id.bSmall);
        mediumB = (RadioButton) findViewById(R.id.mediumb);
        largeB = (RadioButton) findViewById(R.id.largeB);
        bSmall.setOnClickListener(this);
        mediumB.setOnClickListener(this);
        largeB.setOnClickListener(this);

         height =(SeekBar) findViewById(R.id.seekBarH);
        height.setMin(140);
         vlaueHeight=(TextView) findViewById(R.id.textViewH);
        height.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        valueH=progress;
                        vlaueHeight.setText(progress + "cm");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

          weight=(SeekBar) findViewById(R.id.seekBarW);
         weight.setMin(0);
         vlaueWeight=(TextView) findViewById(R.id.textViewW);
        vlaueWeight.setText("0kg");
        weight.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        valueW=progress;
                        vlaueWeight.setText(progress + "kg");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {


                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );
         sendB = (Button) findViewById(R.id.sendB);
         exitB = (Button) findViewById(R.id.exitB);
         sendB.setOnClickListener(this);
         exitB.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent i;
        switch (view.getId()){
            case R.id.buttonMale:
                buttonFemale.setChecked(false);

                break;
            case R.id.buttonFemale:
                buttonMale.setChecked(false);
                break;
            case R.id.bSmall:
                slimness=Constants.SMALL;
                mediumB.setChecked(false);
                largeB.setChecked(false);
                break;

            case R.id.mediumb:
                slimness=Constants.MEDIUM;
                bSmall.setChecked(false);
                largeB.setChecked(false);
                break;
            case R.id.largeB:
                slimness=Constants.LARGE;
                bSmall.setChecked(false);
                mediumB.setChecked(false);
                break;
            case R.id.exitB:
                finish();
                break;

            case  R.id.sendB:
                String arrayInfo[]=new String[4];
                arrayInfo[0]=geyMyFullName();
                arrayInfo[1]=resultBmi();
                arrayInfo[2]=String.valueOf(valueW);
                arrayInfo[3]= String.valueOf(resultOfIdealWeight());
                i = new Intent(this, ResultBmiActivity.class);
                startActivity(i.putExtra("arrayInfo",arrayInfo));
                finish();
                //finish();
                break;
        }


    }

    public String resultBmi(){

        double bmi =calculateBmi();
        String result="";

        if (bmi<=15){
            result=Constants.ANOREXIC;

        }else if (bmi>15 && bmi<18.5){
            result=Constants.UNDERWEIGHT;
        }else if (bmi>18.5 && bmi<24.9){
            result=Constants.NORMAL;

        }else if (bmi> 25 && bmi < 29.9){
            result=Constants.OVERWEIGHT;

        }else if (bmi > 30 && bmi < 35 ){
            result=Constants.OBESE;

        }else if (bmi >= 35){
            result = Constants.EXTREME_OBESE;
        }
      return result;
    }






    private double calculateBmi(){
        double height= valueH/100;
        double weight=valueW;
        return weight/Math.pow(height,2);
    }

    public double resultOfIdealWeight (){
        double idealWeight=0;
        double height=valueH;
        double age= Double.parseDouble(String.valueOf(editTextNumberA.getText()));
        idealWeight=(height-Constants.HUNDRED + (age/Constants.TEN)) *Constants.SMALL*this.slimness;
        return idealWeight;
    }


    public  String geyMyFullName (){
        return editTextTextPersonNameF.getText() + " " + editTextTextPersonNameL.getText() ;

    }

}